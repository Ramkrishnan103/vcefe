import React, {useEffect, useRef, useState} from 'react';
import moment from 'moment';
import {connect} from 'react-redux';
import { fetchDailySales } from '../../../store/action/dailySalesAction';
import { fetchFrontSetting } from '../../../store/action/frontSettingAction';
import { saleExcelAction } from '../../../store/action/salesExcelAction';
import { getFormattedMessage, placeholderText } from '../../../shared/sharedMethod';
import ReactDataTable from '../../../shared/table/ReactDataTable';
import { InputGroup } from 'react-bootstrap';
import ReactSelect from 'react-select';
import { date } from 'faker/lib/locales/az';
import { apiBaseURL } from '../../../constants';
import loader from 'sass-loader';
import { filter } from 'lodash';
import CommonTable from '../../../shared/table/CommonTable';

const DailySalesTab = (props) => {
    const {
        isLoading,
        totalRecord,
        fetchDailySales,
        dailySales,
        frontSetting,
        fetchFrontSetting,
        warehouseValue,
        saleExcelAction, allConfigData
    } = props;
    const currencySymbol = frontSetting && frontSetting.value && frontSetting.value.currency_symbol
    const [isWarehouseValue, setIsWarehouseValue] = useState(false);

    console.log(dailySales)

    useEffect(() => {
        fetchFrontSetting();
    }, [warehouseValue]);

    const itemsValue = dailySales?.length >= 0 && dailySales.map(dailysale => {
        return (
            {
                // date: getFormattedDate(unit.attributes.created_at, allConfigData && allConfigData),
                // time: moment(unit.attributes.created_at).format('LT'),
                counterName:dailysale.attributes.counterName,
                customerName: dailysale.attributes.customerName,
                // base_unit: unit.attributes.base_unit_name?.name ? unit.attributes.base_unit_name?.name : 'N/A',
                paymentType: dailysale.attributes.paymentType,
                customerRegNo:dailysale.attributes.customerRegNo,
                salesValue:dailysale.attributes.salesValue,
            }
        )
    });

    console.log(itemsValue)

    useEffect(() => {
        if(isWarehouseValue === true) {
            saleExcelAction(warehouseValue.value, setIsWarehouseValue);
        }
    }, [isWarehouseValue])


    const columns = [
        {
            name: getFormattedMessage('counterName.title'),
            selector: row => row.counterName,
            sortField: 'counterName',
            sortable: true,
            
        },
       
        {
            name: getFormattedMessage('customerName.title'),
            selector:row => row.customerName,
            sortField: 'customerName',
            sortable: true,
        },
         {
            name: getFormattedMessage('paymentType.title'),
            selector:row => row.paymentType,
            sortField: 'paymentType',
            sortable: true,
          
        },
        {
            name: getFormattedMessage('customerRegNo.title'),
            sortField: 'customerRegNo',
            sortable: true,
            cell: row => {
                return <span className='badge bg-light-info'>
                            <span>{row.customerRegNo}</span>
                        </span>
            }
        },
        {
            name: getFormattedMessage('Sales-value.title'),
            sortField: 'salesValue',
            sortable: true,
            cell: row => {
                return <span className='badge bg-light-info'>
                            <span>{row.salesValue}</span>
                        </span>
            }
        }
    ]


    const [fromDate1,setFromDate1] =useState('')

    const formatDate = (date) => {
        const d = new Date(date);
        const month = (d.getMonth() + 1).toString().padStart(2, '0'); // Add leading zero if necessary
        console.log('month', month);
        const day = d.getDate().toString().padStart(2, '0'); // Add leading zero if necessary
        const year = d.getFullYear();
        return `${day}/${month}/${year}`;
    };

    useEffect(() => {
        const today = new Date();
        setFromDate1(formatDate(today));
    }, []);

    const handleDateChange = (event) => {
        setFromDate1(formatDate(event.target.value));
    };

    console.log(fromDate1)




//     const [formattedDate, setFormattedDate] = useState(''); 

//     const formatDate = (date) => {
//         const d = new Date(date);
//         const day = ("0" + d.getDate()).slice(-2);    
//         const month = ("0" + (d.getMonth() + 1)).slice(-2);    
//         const year = d.getFullYear();    
//         return `${year}-${month}-${day}`;   
//     };
    
//     const today=new Date();
//     const numOfDaysAdded=0;
//     const date=today.setDate(today.getDate() + numOfDaysAdded);
//     const defaultValue= formatDate(date); // YYYY-MM-dd
//     console.log(defaultValue)

   
// const dateValue = moment(defaultValue, "YYYY/MM/DD").format("DD-MM-YYYY");
// console.log(dateValue);

// useEffect(() => {
//     setFormattedDate(moment(dateValue).format("DD/MM/YYYY"));
// }, [dateValue]);

// console.log(formattedDate)

// const handleDateChange = (event) => {
//     setFormattedDate(event.target.value);
// };


    const fromDate=useRef();
    const tooDate=useRef();
    const paymode=useRef();
    const search=useRef();

    const loadReport=()=>{
       let fromDate1=fromDate.current.value 
       let tooDate1= tooDate.current.value
       let paymode1=paymode.current.value
       let serach1=search.current.value
    console.log(fromDate1)
    console.log(tooDate1)
    console.log(paymode1)
    console.log(serach1)
    }

    const loadValues=(filter)=>{
        let values="?fromDate="+fromDate.current.value +"&toDate="+tooDate.current.value 
        + "&counterId=0&paymentType="+paymode.current.value+"&particular="+search.current.value
        console.log(values);
        fetchDailySales(values,filter,true);
    }

    // useEffect(()=>{
    //     loadReport();
    //     fetchDailySales();
    // })

    const onChange = (filter) => {
       
     fetchDailySales(filter, true);
    };

    // useEffect(()=>{
    //       let url=apiBaseURL.DAILY_SALES + "?fromDate=" +"'"+ loadReport.fromDate1 +"'" + "&toDate=" +"'"+loadReport. tooDate1 +"'"
    // + "&counterId=0&paymentType= " + loadReport.paymode1 + "&particular="+loadReport.serach1
    // console.log(url)
    //  fetchDailySales();
    // },[])

   

    const onExcelClick = () => {
        setIsWarehouseValue(true);
    };

   
    return (
        <div className='warehouse_sale_report_table'>

            <div className='row'>
                <div className='col-md-10'></div>
                <div className='col-md-2'>
                        <h4>Select Pay Mode</h4>
                </div>
            </div>

             <div className='row'>
                <div className='col-md-2'>
                        <h4 className='mt-2'>From Date</h4>
                </div>

                 <div className='col-md-2'>
                        <input id1='dateInput' type='date' ref={fromDate}  value={fromDate1}
                onChange={handleDateChange}  className=' form-control rounded text-align-center  align-item-center mr-15 mb-5'></input>
                </div>

                <div className='col-md-1'></div>

                <div className='col-md-2 mt-2'>
                        <h4>To Date</h4>
                </div>

                <div className='col-md-2'>
                        <input id2='dateRequired2' type='date' ref={tooDate}  className='form-control  rounded text-align-center  align-items-center mr-15 mb-5'></input>
                </div>

                <div className='col-md-1'></div>

                <div className='col-md-2'>
                    <select className='w-100 p-3 flex-nowrap dropdown-side-btn- boder-0 form-control' ref={paymode} name='DropDownValue'>
                        <option>Cash</option>
                        <option>Upi</option>
                        <option>Bank</option>
                    </select>
                </div>
            </div>
            <br></br>

            <div className='row'>

                <div className='col-md-2 mt-2'>
                    <h4>Search</h4>
                </div>

                <div className='col-md-7'>
                     <input type='text' ref={search}  placeholder='Customer Name Or Mobile No Or Inv. No' className=' form-control rounded text-align-center  align-items-center mr-15 mb-5'></input>
                </div>

                <div className='col-md-1'></div>

                <div className='col-md-2'>
                    <button className=' form-control border-0 bg-success text-white' onClick={loadValues}   >Generate</button>
                </div>
            </div>
<br></br>
        <CommonTable columns={columns} items={itemsValue} onChange={onChange}  warehouseValue={warehouseValue}
                        isLoading={isLoading} totalRows={totalRecord}/>
        </div>
    )
};

const mapStateToProps = (state) => {
    const {dailySales,isLoading, totalRecord, frontSetting} = state;
    return {dailySales,isLoading, totalRecord, frontSetting}
};

export default connect(mapStateToProps, {fetchFrontSetting, fetchDailySales, saleExcelAction})(DailySalesTab);
