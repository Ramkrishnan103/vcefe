function ProductSalesTab() {
    return(
        <div>
           <h3> Hiii  .. Maja  .....</h3>
        </div>
    )
}

export default ProductSalesTab;