import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { Col, Row, Tab, Tabs } from 'react-bootstrap';
import { fetchMonthSales } from '../../../store/action/monthlySalesAction';
import { faArrowLeft, faArrowRight, faCartPlus, faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import MasterLayout from '../../MasterLayout';
import TopProgressBar from '../../../shared/components/loaders/TopProgressBar';
import { getFormattedMessage, placeholderText } from '../../../shared/sharedMethod';
import TabTitle from '../../../shared/tab-title/TabTitle';
import Widget from '../../../shared/Widget/Widget';
import SalesTab from './SalesTab';
import MonthlySalesTab from './MonthlySalesTab';
//import { fetchDashboard, todaySalePurchaseCount } from '../../../store/action/dashboardAction';
import TodaySalePurchaseCount from '../../dashboard/TodaySalePurchaseCount';
import DailySalesTab from './DailySalesTab';
import { fetchDailySales } from '../../../store/action/dailySalesAction';
import ProductSalesTab from './ProductSalesTab';

const PosSalesReport = ( props ) => {
    const { monthlypossales, fetchMonthSales,monthlySales,fetchDailySales,dailySales,dailypossales,productposSales,monthlySalesReportData, allConfigData } = props;
    const [monthlySalesValue, setmonthlySalesValue ] = useState( { label: getFormattedMessage( "unit.filter.all.label" ), value: null } );
    const[dailySalesValue,setDailySalesValue]=useState({label:getFormattedMessage("unit.filter.all.label"),value:null});
    const [productSalesValue,setProductSalesValue] =useState({label:getFormattedMessage("unit.filter.all.label"),value:null})
    const [ key, setKey ] = useState( 'sales' );
    console.log(dailySalesValue)

    // useEffect( () => {
    //     //fetchAllWarehouses();
    // }, [] );

    useEffect( () => {
        fetchMonthSales( monthlySalesValue.value );
    }, [ monthlySalesValue ] );
console.log("hiii  Jiiiiii :)")


// useEffect (()=> {
//     fetchDailySales(dailySalesValue.value);
// },[dailySalesValue]);


    // const onWarehouseChange = ( obj ) => {
    //     setmonthlySalesValue( obj );
    // };

    // useEffect(()=>{
    //     fetchDailySales(dailySalesValue.value);
    // },[dailySalesValue]);




    // const onChange = (filter) => {
    //     fetchDashboard(filter, true);
    // };

    const array = monthlypossales   
    const newFirstElement = { attributes: { name: getFormattedMessage( "report-all.warehouse.label" ) }, id: null }
    const newArray = [ newFirstElement ].concat( array )


    const array1=dailypossales
    const newFirstElement1={attributes:{name:getFormattedMessage("report-all.warehouse.label")},id:null}
    const newArray1=[newFirstElement1].concat(array1)

    const array2 = productposSales
    const newFirstElement2 = { attributes: { name: getFormattedMessage( "report-all.warehouse.label" ) }, id: null }
    const newArray2 = [ newFirstElement2 ].concat( array2 )



    return (
        

        <div style={{backgroundColor:"white",height:"100%"}}>
        <MasterLayout>
            <TopProgressBar />
            <TabTitle title={placeholderText( 'warehouse.reports.title' )} />
            {/* <Col md={4} className='mx-auto mb-5 col-12'>
                {newArray &&
                    <ReactSelect data={newArray} onChange={onWarehouseChange} defaultValue={newArray[ 0 ] ? {
                        label: newArray[ 0 ].attributes.name,
                        value: newArray[ 0 ].id
                    } : ''}
                        title={getFormattedMessage( 'warehouse.title' )} errors={''} isRequired
                        placeholder={placeholderText( 'purchase.select.warehouse.placeholder.label' )} />}
            </Col> */}
{/*            
            <Row className='g-4'>
                <Widget title={getFormattedMessage( 'sales.title' )}
                    icon={<FontAwesomeIcon icon={faShoppingCart} className='fs-1-xl text-white' />}
                    currency={''} className='bg-primary' iconClass='bg-cyan-300'
                   value={monthlySales?.attributes?.sum(salesValue) ? parseFloat( monthlySales?.attributes?.sum(salesValue)).toFixed( 2 ) : '0.00'}  />

                <Widget title={getFormattedMessage( 'purchases.title' )}
                    className='bg-success' iconClass='bg-green-300'
                    icon={<FontAwesomeIcon icon={faCartPlus} className='fs-1-xl text-white' />} currency={''}
                    value={monthlySales?.attributes?.salesValue ? parseFloat( monthlySales?.attributes?.salesValue).toFixed( 2 ) : '0.00'}  />

                <Widget title={getFormattedMessage( 'dashboard.salesReturn.title' )}
                    className='bg-info' iconClass='bg-blue-300'
                    icon={<FontAwesomeIcon icon={faArrowRight} className='fs-1-xl text-white' />}
                    currency={''}
                    value={'0.00'} />

                <Widget title={getFormattedMessage( 'dashboard.purchaseReturn.title' )}
                    className='bg-warning' iconClass='bg-yellow-300'
                    icon={<FontAwesomeIcon icon={faArrowLeft} className='fs-1-xl text-white' />}
                    currency={''}
                    value={'0.00'} />
                    
            </Row> */}

            <h2 style={{textAlign:'center',color:'green'}}>Sales Report</h2>
            
            <Tabs defaultActiveKey='sales' id='uncontrolled-tab-example' onSelect={( k ) => setKey( k )}
                className='mt-7 mb-5'>

                <Tab eventKey='sales'  title={getFormattedMessage('monthlySales.title' )}
                    tabClassName='position-relative mb-3 me-7'>
                        
                       
                    <div className='w-100 mx-auto border-radius-50'>
                        {key === 'sales' &&  <MonthlySalesTab allConfigData={allConfigData} monthlySalesValue={monthlySalesValue  } />}
                    </div>
                </Tab>
                 <Tab eventKey='sales-return' title={getFormattedMessage( 'DailySales.title' )}
                    tabClassName='position-relative mb-3 me-7'>
                    <div className='w-100 mx-auto'>
                        {key === 'sales-return' && <DailySalesTab allConfigData={allConfigData}  dailySalesValue={dailySalesValue  } />}
                    </div>
                </Tab>
                <Tab eventKey='sales1' title={getFormattedMessage( 'ProductSales.title' )}
                    tabClassName='position-relative mb-3 me-7'>
                    <div className='w-100 mx-auto'>
                        {key === 'sales-return' && <ProductSalesTab allConfigData={allConfigData}  productSalesValue={productposSales  } />}
                    </div>
                </Tab>
               {/* <Tab eventKey='purchase-return' title={getFormattedMessage( 'purchases.return.title' )}
                    tabClassName='position-relative mb-3 me-7'>
                    <div className='w-100 mx-auto'>
                        {key === 'purchase-return' && <PurchaseReturnTab allConfigData={allConfigData} warehouseValue={warehouseValue} />}
                    </div>
                </Tab>
                <Tab eventKey='expenses' title={getFormattedMessage( 'expenses.title' )}
                    tabClassName='position-relative mb-3'>
                    <div className='w-100 mx-auto'>
                        {key === 'expenses' && <ExpensesTab allConfigData={allConfigData} warehouseValue={warehouseValue} />}
                    </div>
                </Tab> */}
            </Tabs>
        </MasterLayout>
        </div>
        
    )
};

const mapStateToProps = ( state ) => {
    const { monthlySales,monthlypossales,dailypossales, dailySales,monthlySalesReportData,allConfigData } = state;
    return { monthlySales,monthlypossales,dailypossales,dailySales,monthlySalesReportData, allConfigData }
};
export default connect( mapStateToProps, { fetchMonthSales,fetchDailySales } )( PosSalesReport );

