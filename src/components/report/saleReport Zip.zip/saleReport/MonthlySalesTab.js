import React, { useEffect, useRef, useState } from "react";
import moment from "moment";
import { connect } from "react-redux";
import {
  fetchMonthSales,
  fetchMonthSalesparam,
} from "../../../store/action/monthlySalesAction";
import { fetchFrontSetting } from "../../../store/action/frontSettingAction";
import { saleExcelAction } from "../../../store/action/salesExcelAction";
import {
  getFormattedMessage,
  placeholderText,
} from "../../../shared/sharedMethod";
import ReactDataTable from "../../../shared/table/ReactDataTable";
import { Button, Form, InputGroup } from "react-bootstrap-v5";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { faPrint } from "@fortawesome/free-solid-svg-icons";
import { faFileExcel } from "@fortawesome/free-solid-svg-icons";
import { faFilePdf } from "@fortawesome/free-solid-svg-icons";
import ReactSelect from "../../../shared/select/reactSelect";
import { fetchAcYear } from "../../../store/action/acYearAction";
import { filter, stubString } from "lodash";
import allConfigReducer from "../../../store/reducers/allConfigReducer";
import {
  ActionOnSet,
  FONT_WEIGHT,
} from "ag-charts-community/dist/esm/es6/module-support";
import { act } from "react";
import loader from "sass-loader";
import { LinearGradient } from "ag-charts-community/dist/esm/es6/scene/gradient/linearGradient";
import { color } from "faker/lib/locales/az/commerce";
import "./monthlySalesTab.css";
import Footer from "../../footer/Footer";
import CommonTable from "../../../shared/table/CommonTable";

const MonthlySalesTab = (props) => {
  const {
    isLoading,
    totalRecord,
    fetchMonthSales,
    fetchMonthSalesparam,
    monthlySales,
    frontSetting,
    fetchFrontSetting,
    warehouseValue,
    saleExcelAction,
    allConfigData,
    acYear,
    fetchAcYear,
  } = props;
  const currencySymbol =
    frontSetting && frontSetting.value && frontSetting.value.currency_symbol;
  const [isWarehouseValue, setIsWarehouseValue] = useState(false);

  console.log(acYear);

  const searchRef = useRef();

  useEffect(() => {
    fetchFrontSetting();
  }, [warehouseValue]);

  useEffect(() => {
    if (searchRef.current) {
      searchRef.current.focus();
    }
  }, []);

  const itemsValue =
    monthlySales?.length >= 0 &&
    monthlySales.map((monthSales) => {
      return {
        // date: getFormattedDate(unit.attributes.created_at, allConfigData && allConfigData),
        // time: moment(unit.attributes.created_at).format('LT'),
        monthYear: monthSales.monthYear,
        //  year: monthSales.attributes.year,
        // base_unit: unit.attributes.base_unit_name?.name ? unit.attributes.base_unit_name?.name : 'N/A',
        //  month: monthSales.attributes.month,
        salesValue: monthSales.attributes.salesValue,
      };
    });

  //     const acYearsValues =acYear?.length >=0 && acYear.map(acyear => {
  //         return(
  //             {
  //                 acFrom:acyear?.attributes?.acFrom,
  //                 acYear:acyear?.attributes?.acYear
  //             }
  //         )
  //     })
  // console.log(acYearsValues)
  //  const columns1 = [
  //     {
  //         name: getFormattedMessage('monthlySales.title'),
  //         selector: row => row.acYears,
  //         sortField: 'acYears',
  //         sortable: true,

  //     }]

  useEffect(() => {
    if (isWarehouseValue === true) {
      saleExcelAction(warehouseValue.value, setIsWarehouseValue);
    }
  }, [isWarehouseValue]);

  const columns = [
    {
      name: (
       
          getFormattedMessage("monthlySales.title")
        
      ),
      // selector: (row) => row.monthYear,
      sortField: "monthYear",
      sortable: true,
      cell: (row) => {
        return (
          <span className="badge bg-light-danger">
            <span>{row.monthYear}</span>
          </span>
        );
      },

    },

   
    {
      name: (
        
          getFormattedMessage("Sales-value.title")
      ),
      sortField: "salesValue",
      sortable: true,
      cell: (row) => {
        return (
          <span className="badge bg-light-info">
            <span>{row.salesValue}</span>
          </span>
        );
      },
    },
  ];

  const footers = [
    {
      name: getFormattedMessage("totalSales.title"),
        
       selector: (row) => row.totalValue,
       sortField: "totalValue",
       sortable: true, 
    }
  ];

  console.log(footers)

  // const addAcyearData=(acYearValue)=> {
  //     addAcYear(acYearValue)
  // }

  useEffect(() => {
    fetchAcYear();
  }, []);

  const [isClearDropdown, setIsClearDropdown] = useState(true);
  const [isDropdown, setIsDropdown] = useState(true);
  const [errors, setErrors] = useState();
  const [acYears, setAcYears] = useState({
    acFrom: 0,
    acTo: 0,
    acYear: "",
  });

  const onTaxChange = (obj) => {
    console.log("onTaxChange obj", obj);
    const new_values = { value: obj?.value ?? 0, label: obj?.label };
    setIsClearDropdown(false);
    setIsDropdown(false);
    setAcYears({ ...acYears, acYear: new_values });
    setErrors("");

    let values =
      "?fromDate='" +
      new_values.label.substr(0, 4) +
      "-04-01'" +
      "&toDate='" +
      new_values.label.substr(5, 9) +
      "-03-31'";

    console.log(values);
    fetchMonthSalesparam(values, filter, true);
  };

  // const fromDate=useRef();
  // const tooDate=useRef();

  // const loadReport=()=>{
  //    let fromDate1=fromDate.current.value
  //    let tooDate1= tooDate.current
  // console.log(fromDate1)
  // console.log(tooDate1)

  // }

  const loadValues = (obj) => {
    

    console.log("onTaxChange obj", obj);
    const new_values = { value: obj?.value ?? 0, label: obj?.label };
    setIsClearDropdown(false);
    setIsDropdown(false);
    setAcYears({ ...acYears, acYear: new_values });
    setErrors("");
    let values =
      "?fromDate='" +
      new_values.label.substr(0, 4) +
      "-04-01'" +
      "&toDate='" +
      new_values.label.substr(5, 9) +
      "-03-31'";

    console.log(values);
    fetchMonthSalesparam(values, filter, true);
  };

 
  useEffect(() => {
    fetchAcYear();
  }, []);

  const acFrom = useRef();

  const loadReport = () => {
    let acFrom1 = acFrom.current.value;

    console.log(acFrom1);
  };

  

  const onChange = (filter) => {
    fetchMonthSales(filter, true);
  };

  

  return (
    <div className="warehouse_sale_report_table">
     
      <br></br>

      <div className="row">
        <div className="col-md-3">
          <input
            className="form-control wd-100"
            placeholder="Search"
            ref={searchRef}
          />
          {/* <FontAwesomeIcon
            icon={faMagnifyingGlass}
            style={{ marginTop: "-66px", marginLeft: "10px" }}
          /> */}
        </div>
        <div className="col-md-2">
          <h3 className="mt-3" style={{ marginLeft: "35px" }}>
            Ac Year
          </h3>
        </div>

        <div className="col-md-3">
          {/* <select className='w-100 h-100  rounded text-align-center border-0 align-items-center '>
           */}
          <InputGroup className="flex-nowrap dropdown-side-btn text-black">
            <ReactSelect
              className="position-relative"
              placeholder={placeholderText("globally.input.AcYear.label")}
              //   defaultValue={acYearValue?.acYear}
              //   value={acYearValue?.acYear}
              //isRequired={true}
              //columns={columns1}
              //   items={acYearsValues}
              ref={acFrom}
              // ref1={acTo}
              data={acYear}
            onChange={loadValues}

              // addAcyearData={addAcyearData}
              //   errors={errors["acYear"]}
              //onChange={setAcYearValue}
            />
          </InputGroup>

          {/* </select> */}
        </div>

        <div className="col-md-1"></div>
        <div className="col-md-3">
          <button
            style={{
              border: "none",
              borderRadius: "10px",
              width: "170px",
              height: "40px",
            }}
          >
            <FontAwesomeIcon
              icon={faPrint}
              className="fa-2x search-icon"
              style={{ color: "black" }}
            ></FontAwesomeIcon>
          
         
            <FontAwesomeIcon
              icon={faFileExcel}
              className="fa-2x search-icon "
              style={{ color: "green",paddingLeft:"10px"}}
            ></FontAwesomeIcon>
         
            
          
            <FontAwesomeIcon
              icon={faFilePdf}
              className="fa-2x search-icon"
              style={{ color: "red" ,paddingLeft:"10px"}}
            ></FontAwesomeIcon>

          </button>
        </div>
        {/* <div className="col-md-2">
          <button
            className=" w-100 h-100 form-control border-0 bg-success text-white"
            onClick={loadValues}
          >
            Generate
          </button>
        </div> */}
      </div>
<br></br>
      <CommonTable
      
        columns={columns}
        items={itemsValue}
       footers={itemsValue.length-1}
        onChange={onChange}
        warehouseValue={warehouseValue}
        isLoading={isLoading}
        totalRows={totalRecord}
        
      />
    </div>
  );
};

const mapStateToProps = (state) => {
  const { isLoading, totalRecord, monthlySales, frontSetting, acYear } = state;
  return { isLoading, totalRecord, monthlySales, frontSetting, acYear };
};

export default connect(mapStateToProps, {
  fetchFrontSetting,
  fetchMonthSales,
  saleExcelAction,
  fetchAcYear,
  fetchMonthSalesparam,
})(MonthlySalesTab);
